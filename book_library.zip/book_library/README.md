# Book Library Service

Ứng dụng quản lý thư viện sách được xây dựng với Django và Django REST Framework.

## Tính năng

- 📚 Quản lý sách (CRUD)
- 👤 Quản lý tác giả
- 📁 Quản lý danh mục
- 📖 Quản lý mượn/trả sách
- 🔍 Tìm kiếm sách nâng cao
- 👥 Quản lý người dùng
- 🔐 Xác thực người dùng
- 📊 Admin interface

## Cài đặt

### 1. Tạo virtual environment

```bash
python -m venv venv
source venv/bin/activate  # Trên Windows: venv\Scripts\activate
```

### 2. Cài đặt dependencies

```bash
pip install -r requirements.txt
```

### 3. Chạy migrations

```bash
python manage.py migrate
```

### 4. Tạo superuser

```bash
python manage.py createsuperuser
```

### 5. Chạy server

```bash
python manage.py runserver
```

Server sẽ chạy tại `http://127.0.0.1:8000/`

## API Endpoints

### Authors (Tác giả)
- `GET /api/authors/` - Danh sách tác giả
- `POST /api/authors/` - Tạo tác giả mới
- `GET /api/authors/{id}/` - Chi tiết tác giả
- `PUT/PATCH /api/authors/{id}/` - Cập nhật tác giả
- `DELETE /api/authors/{id}/` - Xóa tác giả
- `GET /api/authors/{id}/books/` - Danh sách sách của tác giả

### Categories (Danh mục)
- `GET /api/categories/` - Danh sách danh mục
- `POST /api/categories/` - Tạo danh mục mới
- `GET /api/categories/{id}/` - Chi tiết danh mục
- `PUT/PATCH /api/categories/{id}/` - Cập nhật danh mục
- `DELETE /api/categories/{id}/` - Xóa danh mục
- `GET /api/categories/{id}/books/` - Danh sách sách trong danh mục

### Books (Sách)
- `GET /api/books/` - Danh sách sách
- `POST /api/books/` - Tạo sách mới
- `GET /api/books/{id}/` - Chi tiết sách
- `PUT/PATCH /api/books/{id}/` - Cập nhật sách
- `DELETE /api/books/{id}/` - Xóa sách
- `GET /api/books/available/` - Danh sách sách có sẵn
- `GET /api/books/search/?q=keyword&author=name&category=name&status=available` - Tìm kiếm sách

### Borrow Records (Bản ghi mượn)
- `GET /api/borrows/` - Danh sách bản ghi mượn (chỉ của user hiện tại, trừ admin)
- `POST /api/borrows/` - Tạo bản ghi mượn mới
- `GET /api/borrows/{id}/` - Chi tiết bản ghi mượn
- `PUT/PATCH /api/borrows/{id}/` - Cập nhật bản ghi mượn
- `POST /api/borrows/{id}/return_book/` - Trả sách
- `GET /api/borrows/my_borrows/` - Danh sách sách đang mượn của user
- `GET /api/borrows/overdue/` - Danh sách sách quá hạn

### Users (Người dùng)
- `GET /api/users/` - Danh sách người dùng
- `GET /api/users/{id}/` - Chi tiết người dùng
- `GET /api/users/me/` - Thông tin user hiện tại

## Admin Interface

Truy cập `http://127.0.0.1:8000/admin/` để quản lý dữ liệu qua giao diện admin.

Đăng nhập bằng tài khoản superuser đã tạo.

## Models

### Author (Tác giả)
- name: Tên tác giả
- bio: Tiểu sử
- birth_date: Ngày sinh
- nationality: Quốc tịch

### Category (Danh mục)
- name: Tên danh mục
- description: Mô tả

### Book (Sách)
- title: Tiêu đề
- isbn: Mã ISBN
- author: Tác giả (ForeignKey)
- category: Danh mục (ForeignKey)
- description: Mô tả
- publisher: Nhà xuất bản
- publish_date: Ngày xuất bản
- pages: Số trang
- language: Ngôn ngữ
- status: Trạng thái (available, borrowed, reserved, maintenance)
- total_copies: Tổng số bản
- available_copies: Số bản có sẵn
- cover_image: Ảnh bìa

### BorrowRecord (Bản ghi mượn)
- book: Sách (ForeignKey)
- borrower: Người mượn (ForeignKey to User)
- borrow_date: Ngày mượn
- due_date: Ngày hẹn trả
- return_date: Ngày trả
- status: Trạng thái (borrowed, returned, overdue, lost)
- notes: Ghi chú

## Phân quyền

- **IsAuthenticatedOrReadOnly**: Cho phép đọc công khai, chỉ cho phép ghi khi đã đăng nhập (Authors, Categories, Books)
- **IsAuthenticated**: Yêu cầu đăng nhập cho tất cả thao tác (BorrowRecords, Users)

## Tìm kiếm và Lọc

API hỗ trợ:
- Tìm kiếm: Sử dụng tham số `search` trong URL
- Sắp xếp: Sử dụng tham số `ordering`
- Phân trang: Tự động với 20 items mỗi trang

## Ví dụ sử dụng API

### Tạo tác giả mới
```bash
curl -X POST http://127.0.0.1:8000/api/authors/ \
  -H "Content-Type: application/json" \
  -d '{"name": "Nguyễn Nhật Ánh", "nationality": "Việt Nam"}'
```

### Tìm kiếm sách
```bash
curl http://127.0.0.1:8000/api/books/search/?q=Harry&author=Rowling
```

### Mượn sách
```bash
curl -X POST http://127.0.0.1:8000/api/borrows/ \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer YOUR_TOKEN" \
  -d '{"book": 1, "due_date": "2024-12-31"}'
```

## Phát triển

### Chạy tests
```bash
python manage.py test
```

### Tạo migrations mới
```bash
python manage.py makemigrations
python manage.py migrate
```

## License

MIT


