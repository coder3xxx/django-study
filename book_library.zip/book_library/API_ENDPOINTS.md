# API Endpoints - Book Library

## 🔗 Base URL

```
http://127.0.0.1:8000/api/
```

## 📚 Danh Sách Endpoints

### **Authors (Tác giả)**

```
GET    /api/authors/                    # Danh sách tác giả
POST   /api/authors/                    # Tạo tác giả mới
GET    /api/authors/{id}/               # Chi tiết tác giả
PUT    /api/authors/{id}/               # Cập nhật tác giả (full)
PATCH  /api/authors/{id}/               # Cập nhật tác giả (partial)
DELETE /api/authors/{id}/               # Xóa tác giả
GET    /api/authors/{id}/books/         # Sách của tác giả
```

### **Categories (Danh mục)**

```
GET    /api/categories/                 # Danh sách danh mục
POST   /api/categories/                 # Tạo danh mục mới
GET    /api/categories/{id}/           # Chi tiết danh mục
PUT    /api/categories/{id}/           # Cập nhật danh mục (full)
PATCH  /api/categories/{id}/           # Cập nhật danh mục (partial)
DELETE /api/categories/{id}/           # Xóa danh mục
GET    /api/categories/{id}/books/      # Sách trong danh mục
```

### **Books (Sách)**

```
GET    /api/books/                      # Danh sách sách
POST   /api/books/                      # Tạo sách mới
GET    /api/books/{id}/                 # Chi tiết sách
PUT    /api/books/{id}/                 # Cập nhật sách (full)
PATCH  /api/books/{id}/                 # Cập nhật sách (partial)
DELETE /api/books/{id}/                 # Xóa sách
GET    /api/books/available/           # Sách có sẵn
GET    /api/books/search/?q=...         # Tìm kiếm sách
```

**Tìm kiếm nâng cao:**

```
GET /api/books/search/?q=python&author=John&category=Tech&status=available
```

### **Borrows (Mượn sách)**

```
GET    /api/borrows/                    # Danh sách bản ghi mượn (cần auth)
POST   /api/borrows/                    # Tạo bản ghi mượn mới (cần auth)
GET    /api/borrows/{id}/               # Chi tiết bản ghi (cần auth)
PUT    /api/borrows/{id}/               # Cập nhật bản ghi (full, cần auth)
PATCH  /api/borrows/{id}/               # Cập nhật bản ghi (partial, cần auth)
DELETE /api/borrows/{id}/               # Xóa bản ghi (cần auth)
POST   /api/borrows/{id}/return_book/   # Trả sách (cần auth)
GET    /api/borrows/my_borrows/         # Sách đang mượn của user (cần auth)
GET    /api/borrows/overdue/            # Sách quá hạn (cần auth)
```

### **Users (Người dùng)**

```
GET    /api/users/                      # Danh sách users (read-only, cần auth)
GET    /api/users/{id}/                 # Chi tiết user (read-only, cần auth)
GET    /api/users/me/                   # Thông tin user hiện tại (cần auth)
```

## ⚠️ Lưu Ý Quan Trọng

1. **Số nhiều**: Tất cả endpoints dùng số nhiều:

   - ✅ `/api/categories/` (đúng)
   - ❌ `/api/category/` (sai)

2. **Dấu `/` ở cuối**: Nên có dấu `/` ở cuối URL:

   - ✅ `/api/categories/` (đúng)
   - ⚠️ `/api/categories` (có thể hoạt động nhưng không chuẩn)

3. **Không có `/library/`**:

   - ✅ `/api/categories/` (đúng)
   - ❌ `/api/library/categories/` (sai)

4. **Authentication**:
   - Endpoints `/api/borrows/` và `/api/users/` yêu cầu đăng nhập
   - Các endpoints khác cho phép đọc công khai, nhưng chỉnh sửa cần đăng nhập

## 🔍 Ví Dụ Sử Dụng

### **Lấy danh sách categories:**

```bash
GET http://127.0.0.1:8000/api/categories/
```

### **Tạo category mới:**

```bash
POST http://127.0.0.1:8000/api/categories/
Content-Type: application/json

{
  "name": "Khoa học viễn tưởng",
  "description": "Thể loại khoa học viễn tưởng"
}
```

### **Tìm kiếm sách:**

```bash
GET http://127.0.0.1:8000/api/books/search/?q=python&status=available
```

### **Mượn sách (cần authentication):**

```bash
POST http://127.0.0.1:8000/api/borrows/
Authorization: Token your_token_here
Content-Type: application/json

{
  "book": 1,
  "due_date": "2025-12-15"
}
```

## 🧪 Test với cURL

```bash
# Lấy danh sách categories
curl http://127.0.0.1:8000/api/categories/

# Lấy danh sách books
curl http://127.0.0.1:8000/api/books/

# Tìm kiếm sách
curl "http://127.0.0.1:8000/api/books/search/?q=python"
```

## 📝 Pagination

Tất cả endpoints list đều có pagination (mặc định 20 items/page):

```
GET /api/categories/?page=1
GET /api/categories/?page=2
```

## 🔎 Filtering & Searching

### **Search:**

```
GET /api/authors/?search=John
GET /api/books/?search=python
```

### **Ordering:**

```
GET /api/authors/?ordering=name
GET /api/books/?ordering=-created_at
```
