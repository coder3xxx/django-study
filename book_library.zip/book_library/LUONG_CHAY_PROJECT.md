# Luồng Chạy Của Project Book Library

## 📋 Tổng Quan

Đây là một hệ thống quản lý thư viện sách sử dụng Django REST Framework, cung cấp cả giao diện Admin và API REST.

---

## 🏗️ Cấu Trúc Project

```
book_library/
├── book_library/          # Project chính (settings, URLs root)
│   ├── settings.py        # Cấu hình Django
│   ├── urls.py           # URL routing chính
│   └── wsgi.py/asgi.py   # WSGI/ASGI config
├── library/              # App chính
│   ├── models.py         # Models: Author, Category, Book, BorrowRecord
│   ├── views.py          # ViewSets (API endpoints)
│   ├── serializers.py    # Serializers (chuyển đổi dữ liệu)
│   ├── urls.py           # API routing
│   └── admin.py          # Django Admin configuration
└── manage.py             # Django management script
```

---

## 🔄 Luồng Xử Lý Request

### 1. **Khởi Động Server**

```
python manage.py runserver
```

- Django load settings từ `book_library/settings.py`
- Khởi tạo middleware, apps, database connections
- Server chạy tại `http://127.0.0.1:8000`

### 2. **Request Flow**

```
Client Request
    ↓
book_library/urls.py (URL Dispatcher)
    ↓
    ├── /admin/ → Django Admin Interface
    │   └── library/admin.py (ModelAdmin classes)
    │
    └── /api/ → API Endpoints
        ↓
        library/urls.py (Router)
        ↓
        library/views.py (ViewSets)
        ↓
        library/serializers.py (Data Serialization)
        ↓
        library/models.py (Database)
        ↓
        Response (JSON)
```

---

## 🌐 URL Routing

### **Root URLs** (`book_library/urls.py`)

```python
/admin/          → Django Admin Interface
/api/            → API Endpoints (include library.urls)
```

### **API URLs** (`library/urls.py`)

Sử dụng Django REST Framework Router tự động tạo endpoints:

| Endpoint                         | Method                  | Mô Tả                       |
| -------------------------------- | ----------------------- | --------------------------- |
| `/api/authors/`                  | GET, POST               | Danh sách/Tạo tác giả       |
| `/api/authors/{id}/`             | GET, PUT, PATCH, DELETE | Chi tiết tác giả            |
| `/api/authors/{id}/books/`       | GET                     | Sách của tác giả            |
| `/api/categories/`               | GET, POST               | Danh sách/Tạo danh mục      |
| `/api/categories/{id}/`          | GET, PUT, PATCH, DELETE | Chi tiết danh mục           |
| `/api/categories/{id}/books/`    | GET                     | Sách trong danh mục         |
| `/api/books/`                    | GET, POST               | Danh sách/Tạo sách          |
| `/api/books/{id}/`               | GET, PUT, PATCH, DELETE | Chi tiết sách               |
| `/api/books/available/`          | GET                     | Sách có sẵn                 |
| `/api/books/search/?q=...`       | GET                     | Tìm kiếm sách               |
| `/api/borrows/`                  | GET, POST               | Danh sách/Tạo bản ghi mượn  |
| `/api/borrows/{id}/`             | GET, PUT, PATCH, DELETE | Chi tiết bản ghi            |
| `/api/borrows/{id}/return_book/` | POST                    | Trả sách                    |
| `/api/borrows/my_borrows/`       | GET                     | Sách đang mượn của user     |
| `/api/borrows/overdue/`          | GET                     | Sách quá hạn                |
| `/api/users/`                    | GET                     | Danh sách users (read-only) |
| `/api/users/me/`                 | GET                     | Thông tin user hiện tại     |

---

## 📊 Models & Relationships

```
Author (Tác giả)
    ↓ (1:N)
Book (Sách)
    ↑ (N:1)
Category (Danh mục)

Book (Sách)
    ↓ (1:N)
BorrowRecord (Bản ghi mượn)
    ↑ (N:1)
User (Người dùng)
```

### **Models:**

1. **Author**: Tác giả sách
2. **Category**: Danh mục sách
3. **Book**: Sách (liên kết với Author và Category)
4. **BorrowRecord**: Bản ghi mượn sách (liên kết với Book và User)

---

## 🔐 Authentication & Permissions

### **API Permissions:**

- **IsAuthenticatedOrReadOnly**: Cho phép đọc công khai, chỉnh sửa cần đăng nhập
  - Áp dụng cho: Authors, Categories, Books
- **IsAuthenticated**: Yêu cầu đăng nhập
  - Áp dụng cho: BorrowRecords, Users

### **BorrowRecord Access Control:**

- **Staff users**: Xem tất cả bản ghi mượn
- **Regular users**: Chỉ xem bản ghi của chính mình

---

## 🎯 Chi Tiết ViewSets

### **1. AuthorViewSet**

- **Queryset**: Tất cả tác giả
- **Search**: Theo tên, quốc tịch
- **Custom Action**: `books/` - Lấy sách của tác giả

### **2. CategoryViewSet**

- **Queryset**: Tất cả danh mục
- **Search**: Theo tên
- **Custom Action**: `books/` - Lấy sách trong danh mục

### **3. BookViewSet**

- **Queryset**: Tất cả sách (với select_related để tối ưu)
- **Search**: Theo tiêu đề, ISBN, tên tác giả, nhà xuất bản
- **Custom Actions**:
  - `available/` - Sách có sẵn (status='available' và available_copies > 0)
  - `search/?q=...&author=...&category=...&status=...` - Tìm kiếm nâng cao

### **4. BorrowRecordViewSet**

- **Queryset**: Phụ thuộc vào quyền user
- **Auto-assign**: Tự động gán borrower = user hiện tại khi tạo
- **Custom Actions**:
  - `return_book/` - Trả sách (cập nhật return_date và status)
  - `my_borrows/` - Sách đang mượn của user
  - `overdue/` - Sách quá hạn

### **5. UserViewSet**

- **Read-only**: Chỉ cho phép xem
- **Custom Action**: `me/` - Thông tin user hiện tại

---

## 🔄 Business Logic

### **1. Book Model - Auto Update Available Copies**

```python
def save(self, *args, **kwargs):
    # Tự động cập nhật available_copies khi total_copies thay đổi
    if self.pk:
        old_book = Book.objects.get(pk=self.pk)
        if old_book.total_copies != self.total_copies:
            diff = self.total_copies - old_book.total_copies
            self.available_copies = max(0, self.available_copies + diff)
    super().save(*args, **kwargs)
```

### **2. BorrowRecord Model - Auto Update Book Status**

```python
def save(self, *args, **kwargs):
    is_new = self.pk is None
    super().save(*args, **kwargs)

    if is_new and self.status == 'borrowed':
        # Giảm số bản có sẵn khi mượn
        self.book.available_copies = max(0, self.book.available_copies - 1)
        if self.book.available_copies == 0:
            self.book.status = 'borrowed'
        self.book.save()
    elif self.status == 'returned' and self.return_date:
        # Tăng số bản có sẵn khi trả
        self.book.available_copies = min(self.book.total_copies, self.book.available_copies + 1)
        if self.book.available_copies > 0:
            self.book.status = 'available'
        self.book.save()
```

---

## 📝 Serializers

### **Chức năng:**

- Chuyển đổi Model → JSON (serialization)
- Chuyển đổi JSON → Model (deserialization)
- Validation dữ liệu
- Tính toán fields động (books_count, status_display, etc.)

### **Serializer Classes:**

- **AuthorSerializer**: + books_count
- **CategorySerializer**: + books_count
- **BookSerializer**: + author_name, category_name, status_display
- **BookDetailSerializer**: Nested Author và Category
- **BorrowRecordSerializer**: + book_title, borrower_username, status_display
- **BorrowRecordDetailSerializer**: Nested Book
- **UserSerializer**: + borrow_records_count

---

## 🎨 Django Admin

### **Admin Classes:**

1. **AuthorAdmin**: Quản lý tác giả
2. **CategoryAdmin**: Quản lý danh mục
3. **BookAdmin**: Quản lý sách (với fieldsets)
4. **BorrowRecordAdmin**: Quản lý bản ghi mượn (với readonly_fields cho borrow_date)

### **Truy cập:**

- URL: `http://127.0.0.1:8000/admin/`
- Cần tạo superuser: `python manage.py createsuperuser`

---

## 🗄️ Database

- **Engine**: SQLite (db.sqlite3)
- **Migrations**: `library/migrations/`
- **Tạo migrations**: `python manage.py makemigrations`
- **Áp dụng migrations**: `python manage.py migrate`

---

## 🔍 Ví Dụ Request Flow

### **Ví dụ 1: Lấy danh sách sách**

```
GET /api/books/
    ↓
library/urls.py → router.register('books', BookViewSet)
    ↓
library/views.py → BookViewSet.list()
    ↓
Book.objects.select_related('author', 'category').all()
    ↓
BookSerializer(books, many=True)
    ↓
Response JSON: [{id, title, author_name, ...}, ...]
```

### **Ví dụ 2: Mượn sách**

```
POST /api/borrows/
Body: {book: 1, due_date: "2025-12-15"}
    ↓
library/views.py → BorrowRecordViewSet.create()
    ↓
perform_create() → borrower = request.user (auto-assign)
    ↓
BorrowRecordSerializer → Validation
    ↓
BorrowRecord.save() → Trigger Book status update
    ↓
Response JSON: {id, book_title, borrower_username, ...}
```

### **Ví dụ 3: Trả sách**

```
POST /api/borrows/1/return_book/
    ↓
library/views.py → BorrowRecordViewSet.return_book()
    ↓
borrow_record.return_date = timezone.now().date()
borrow_record.status = 'returned'
borrow_record.save() → Trigger Book status update
    ↓
Response JSON: {id, status: 'returned', return_date, ...}
```

---

## 🚀 Các Lệnh Quan Trọng

```bash
# Chạy server
python manage.py runserver

# Tạo superuser
python manage.py createsuperuser

# Tạo migrations
python manage.py makemigrations

# Áp dụng migrations
python manage.py migrate

# Shell Django
python manage.py shell

# Collect static files
python manage.py collectstatic
```

---

## 📌 Tóm Tắt

1. **Request** → `book_library/urls.py` (routing chính)
2. **API Request** → `library/urls.py` (router tự động tạo endpoints)
3. **ViewSet** → Xử lý logic, permissions, queryset
4. **Serializer** → Validation, serialization/deserialization
5. **Model** → Database operations, business logic
6. **Response** → JSON data trả về client

Hệ thống sử dụng **Django REST Framework** với **ViewSets** và **Routers** để tự động tạo CRUD endpoints, kết hợp với **Django Admin** để quản lý dữ liệu qua giao diện web.
