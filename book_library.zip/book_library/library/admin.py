from django.contrib import admin
from .models import Author, Category, Book, BorrowRecord


@admin.register(Author)
class AuthorAdmin(admin.ModelAdmin):
    list_display = ['name', 'nationality', 'birth_date', 'created_at']
    search_fields = ['name', 'nationality']
    list_filter = ['nationality', 'created_at']
    readonly_fields = ['created_at', 'updated_at']


@admin.register(Category)
class CategoryAdmin(admin.ModelAdmin):
    list_display = ['name', 'created_at']
    search_fields = ['name']
    readonly_fields = ['created_at']


@admin.register(Book)
class BookAdmin(admin.ModelAdmin):
    list_display = ['title', 'author', 'category', 'status', 'available_copies', 'total_copies', 'created_at']
    list_filter = ['status', 'category', 'language', 'created_at']
    search_fields = ['title', 'isbn', 'author__name', 'publisher']
    readonly_fields = ['created_at', 'updated_at']
    fieldsets = (
        ('Thông tin cơ bản', {
            'fields': ('title', 'isbn', 'author', 'category', 'description')
        }),
        ('Thông tin xuất bản', {
            'fields': ('publisher', 'publish_date', 'pages', 'language')
        }),
        ('Quản lý kho', {
            'fields': ('status', 'total_copies', 'available_copies', 'cover_image')
        }),
        ('Thông tin hệ thống', {
            'fields': ('created_at', 'updated_at'),
            'classes': ('collapse',)
        }),
    )


@admin.register(BorrowRecord)
class BorrowRecordAdmin(admin.ModelAdmin):
    list_display = ['book', 'borrower', 'borrow_date', 'due_date', 'return_date', 'status']
    list_filter = ['status', 'borrow_date', 'due_date']
    search_fields = ['book__title', 'borrower__username', 'borrower__email']
    readonly_fields = ['borrow_date', 'created_at', 'updated_at']
    date_hierarchy = 'borrow_date'
    fieldsets = (
        ('Thông tin mượn', {
            'fields': ('book', 'borrower', 'borrow_date', 'due_date', 'return_date', 'status')
        }),
        ('Ghi chú', {
            'fields': ('notes',)
        }),
        ('Thông tin hệ thống', {
            'fields': ('created_at', 'updated_at'),
            'classes': ('collapse',)
        }),
    )


