from rest_framework import serializers
from django.contrib.auth.models import User
from .models import Author, Category, Book, BorrowRecord


class AuthorSerializer(serializers.ModelSerializer):
    books_count = serializers.SerializerMethodField()

    class Meta:
        model = Author
        fields = [
            "id",
            "name",
            "bio",
            "birth_date",
            "nationality",
            "books_count",
            "created_at",
            "updated_at",
        ]
        read_only_fields = ["created_at", "updated_at"]

    def get_books_count(self, obj):
        return obj.books.count()


class CategorySerializer(serializers.ModelSerializer):
    books_count = serializers.SerializerMethodField()

    class Meta:
        model = Category
        fields = ["id", "name", "description", "books_count", "created_at"]
        read_only_fields = ["created_at"]

    def get_books_count(self, obj):
        return obj.books.count()


class BookSerializer(serializers.ModelSerializer):
    author_name = serializers.CharField(source="author.name", read_only=True)
    category_name = serializers.CharField(source="category.name", read_only=True)
    status_display = serializers.CharField(source="get_status_display", read_only=True)

    class Meta:
        model = Book
        fields = [
            "id",
            "title",
            "isbn",
            "author",
            "author_name",
            "category",
            "category_name",
            "description",
            "publisher",
            "publish_date",
            "pages",
            "language",
            "status",
            "status_display",
            "total_copies",
            "available_copies",
            "cover_image",
            "created_at",
            "updated_at",
        ]
        read_only_fields = ["created_at", "updated_at"]


class BookDetailSerializer(BookSerializer):
    """Serializer chi tiết cho Book với thông tin đầy đủ"""

    author = AuthorSerializer(read_only=True)
    category = CategorySerializer(read_only=True)

    class Meta(BookSerializer.Meta):
        fields = BookSerializer.Meta.fields


class BorrowRecordSerializer(serializers.ModelSerializer):
    book_title = serializers.CharField(source="book.title", read_only=True)
    borrower_username = serializers.CharField(
        source="borrower.username", read_only=True
    )
    status_display = serializers.CharField(source="get_status_display", read_only=True)

    class Meta:
        model = BorrowRecord
        fields = [
            "id",
            "book",
            "book_title",
            "borrower",
            "borrower_username",
            "borrow_date",
            "due_date",
            "return_date",
            "status",
            "status_display",
            "notes",
            "created_at",
            "updated_at",
        ]
        read_only_fields = ["created_at", "updated_at", "borrow_date"]


class BorrowRecordDetailSerializer(BorrowRecordSerializer):
    """Serializer chi tiết cho BorrowRecord"""

    book = BookSerializer(read_only=True)

    class Meta(BorrowRecordSerializer.Meta):
        fields = BorrowRecordSerializer.Meta.fields


class UserSerializer(serializers.ModelSerializer):
    borrow_records_count = serializers.SerializerMethodField()

    class Meta:
        model = User
        fields = [
            "id",
            "username",
            "email",
            "first_name",
            "last_name",
            "borrow_records_count",
        ]
        read_only_fields = ["id"]

    def get_borrow_records_count(self, obj):
        return obj.borrow_records.count()
