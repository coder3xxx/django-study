from django.db import models
from django.contrib.auth.models import User
from django.core.validators import MinValueValidator, MaxValueValidator


class Author(models.Model):
    """Model đại diện cho tác giả sách"""
    name = models.CharField(max_length=200, verbose_name="Tên tác giả")
    bio = models.TextField(blank=True, null=True, verbose_name="Tiểu sử")
    birth_date = models.DateField(blank=True, null=True, verbose_name="Ngày sinh")
    nationality = models.CharField(max_length=100, blank=True, null=True, verbose_name="Quốc tịch")
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        ordering = ['name']
        verbose_name = "Tác giả"
        verbose_name_plural = "Tác giả"

    def __str__(self):
        return self.name


class Category(models.Model):
    """Model đại diện cho danh mục sách"""
    name = models.CharField(max_length=100, unique=True, verbose_name="Tên danh mục")
    description = models.TextField(blank=True, null=True, verbose_name="Mô tả")
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ['name']
        verbose_name = "Danh mục"
        verbose_name_plural = "Danh mục"

    def __str__(self):
        return self.name


class Book(models.Model):
    """Model đại diện cho sách"""
    STATUS_CHOICES = [
        ('available', 'Có sẵn'),
        ('borrowed', 'Đã mượn'),
        ('reserved', 'Đã đặt trước'),
        ('maintenance', 'Bảo trì'),
    ]

    title = models.CharField(max_length=300, verbose_name="Tiêu đề")
    isbn = models.CharField(max_length=13, unique=True, blank=True, null=True, verbose_name="ISBN")
    author = models.ForeignKey(Author, on_delete=models.CASCADE, related_name='books', verbose_name="Tác giả")
    category = models.ForeignKey(Category, on_delete=models.SET_NULL, null=True, related_name='books', verbose_name="Danh mục")
    description = models.TextField(blank=True, null=True, verbose_name="Mô tả")
    publisher = models.CharField(max_length=200, blank=True, null=True, verbose_name="Nhà xuất bản")
    publish_date = models.DateField(blank=True, null=True, verbose_name="Ngày xuất bản")
    pages = models.IntegerField(blank=True, null=True, validators=[MinValueValidator(1)], verbose_name="Số trang")
    language = models.CharField(max_length=50, default='Vietnamese', verbose_name="Ngôn ngữ")
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default='available', verbose_name="Trạng thái")
    total_copies = models.IntegerField(default=1, validators=[MinValueValidator(0)], verbose_name="Tổng số bản")
    available_copies = models.IntegerField(default=1, validators=[MinValueValidator(0)], verbose_name="Số bản có sẵn")
    cover_image = models.ImageField(upload_to='book_covers/', blank=True, null=True, verbose_name="Ảnh bìa")
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        ordering = ['title']
        verbose_name = "Sách"
        verbose_name_plural = "Sách"
        indexes = [
            models.Index(fields=['title']),
            models.Index(fields=['isbn']),
            models.Index(fields=['status']),
        ]

    def __str__(self):
        return f"{self.title} - {self.author.name}"

    def save(self, *args, **kwargs):
        # Tự động cập nhật available_copies khi total_copies thay đổi
        if self.pk:
            old_book = Book.objects.get(pk=self.pk)
            if old_book.total_copies != self.total_copies:
                diff = self.total_copies - old_book.total_copies
                self.available_copies = max(0, self.available_copies + diff)
        super().save(*args, **kwargs)


class BorrowRecord(models.Model):
    """Model đại diện cho bản ghi mượn sách"""
    STATUS_CHOICES = [
        ('borrowed', 'Đang mượn'),
        ('returned', 'Đã trả'),
        ('overdue', 'Quá hạn'),
        ('lost', 'Mất sách'),
    ]

    book = models.ForeignKey(Book, on_delete=models.CASCADE, related_name='borrow_records', verbose_name="Sách")
    borrower = models.ForeignKey(User, on_delete=models.CASCADE, related_name='borrow_records', verbose_name="Người mượn")
    borrow_date = models.DateField(auto_now_add=True, verbose_name="Ngày mượn")
    due_date = models.DateField(verbose_name="Ngày hẹn trả")
    return_date = models.DateField(blank=True, null=True, verbose_name="Ngày trả")
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default='borrowed', verbose_name="Trạng thái")
    notes = models.TextField(blank=True, null=True, verbose_name="Ghi chú")
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        ordering = ['-borrow_date']
        verbose_name = "Bản ghi mượn sách"
        verbose_name_plural = "Bản ghi mượn sách"
        indexes = [
            models.Index(fields=['borrower']),
            models.Index(fields=['status']),
            models.Index(fields=['due_date']),
        ]

    def __str__(self):
        return f"{self.borrower.username} - {self.book.title} ({self.status})"

    def save(self, *args, **kwargs):
        # Cập nhật trạng thái sách khi mượn/trả
        is_new = self.pk is None
        super().save(*args, **kwargs)
        
        if is_new and self.status == 'borrowed':
            # Giảm số bản có sẵn khi mượn
            self.book.available_copies = max(0, self.book.available_copies - 1)
            if self.book.available_copies == 0:
                self.book.status = 'borrowed'
            self.book.save()
        elif self.status == 'returned' and self.return_date:
            # Tăng số bản có sẵn khi trả
            self.book.available_copies = min(self.book.total_copies, self.book.available_copies + 1)
            if self.book.available_copies > 0:
                self.book.status = 'available'
            self.book.save()


