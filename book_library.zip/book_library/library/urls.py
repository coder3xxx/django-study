from django.urls import path, include
from rest_framework.routers import DefaultRouter
from .views import (
    AuthorViewSet,
    CategoryViewSet,
    BookViewSet,
    BorrowRecordViewSet,
    UserViewSet,
)

router = DefaultRouter()
router.register(r"authors", AuthorViewSet, basename="author")
router.register(r"categories", CategoryViewSet, basename="category")
router.register(r"books", BookViewSet, basename="book")
router.register(r"borrows", BorrowRecordViewSet, basename="borrow")
router.register(r"users", UserViewSet, basename="user")

urlpatterns = [
    path("", include(router.urls)),
]
