from rest_framework import viewsets, filters, status
from rest_framework.decorators import action
from rest_framework.response import Response
from rest_framework.permissions import IsAuthenticatedOrReadOnly, IsAuthenticated
from django.contrib.auth.models import User
from django.db.models import Q
from .models import Author, Category, Book, BorrowRecord
from .serializers import (
    AuthorSerializer,
    CategorySerializer,
    BookSerializer,
    BookDetailSerializer,
    BorrowRecordSerializer,
    BorrowRecordDetailSerializer,
    UserSerializer,
)


class AuthorViewSet(viewsets.ModelViewSet):
    """ViewSet cho quản lý tác giả"""

    queryset = Author.objects.all()
    serializer_class = AuthorSerializer
    permission_classes = [IsAuthenticatedOrReadOnly]
    filter_backends = [filters.SearchFilter, filters.OrderingFilter]
    search_fields = ["name", "nationality"]
    ordering_fields = ["name", "created_at"]
    ordering = ["name"]

    @action(detail=True, methods=["get"])
    def books(self, request, pk=None):
        """Lấy danh sách sách của tác giả"""
        author = self.get_object()
        books = author.books.all()
        serializer = BookSerializer(books, many=True)
        return Response(serializer.data)


class CategoryViewSet(viewsets.ModelViewSet):
    """ViewSet cho quản lý danh mục"""

    queryset = Category.objects.all()
    serializer_class = CategorySerializer
    permission_classes = [IsAuthenticatedOrReadOnly]
    filter_backends = [filters.SearchFilter, filters.OrderingFilter]
    search_fields = ["name"]
    ordering_fields = ["name", "created_at"]
    ordering = ["name"]

    @action(detail=True, methods=["get"])
    def books(self, request, pk=None):
        """Lấy danh sách sách trong danh mục"""
        category = self.get_object()
        books = category.books.all()
        serializer = BookSerializer(books, many=True)
        return Response(serializer.data)


class BookViewSet(viewsets.ModelViewSet):
    """ViewSet cho quản lý sách"""

    queryset = Book.objects.select_related("author", "category").all()
    permission_classes = [IsAuthenticatedOrReadOnly]
    filter_backends = [filters.SearchFilter, filters.OrderingFilter]
    search_fields = ["title", "isbn", "author__name", "publisher"]
    ordering_fields = ["title", "created_at", "publish_date"]
    ordering = ["title"]

    def get_serializer_class(self):
        if self.action == "retrieve":
            return BookDetailSerializer
        return BookSerializer

    @action(detail=False, methods=["get"])
    def available(self, request):
        """Lấy danh sách sách có sẵn"""
        books = self.queryset.filter(status="available", available_copies__gt=0)
        page = self.paginate_queryset(books)
        if page is not None:
            serializer = self.get_serializer(page, many=True)
            return self.get_paginated_response(serializer.data)
        serializer = self.get_serializer(books, many=True)
        return Response(serializer.data)

    @action(detail=False, methods=["get"])
    def search(self, request):
        """Tìm kiếm sách nâng cao"""
        query = request.query_params.get("q", "")
        author = request.query_params.get("author", "")
        category = request.query_params.get("category", "")
        status_filter = request.query_params.get("status", "")

        queryset = self.queryset

        if query:
            queryset = queryset.filter(
                Q(title__icontains=query)
                | Q(description__icontains=query)
                | Q(isbn__icontains=query)
            )

        if author:
            queryset = queryset.filter(author__name__icontains=author)

        if category:
            queryset = queryset.filter(category__name__icontains=category)

        if status_filter:
            queryset = queryset.filter(status=status_filter)

        page = self.paginate_queryset(queryset)
        if page is not None:
            serializer = self.get_serializer(page, many=True)
            return self.get_paginated_response(serializer.data)
        serializer = self.get_serializer(queryset, many=True)
        return Response(serializer.data)


class BorrowRecordViewSet(viewsets.ModelViewSet):
    """ViewSet cho quản lý bản ghi mượn sách"""

    permission_classes = [IsAuthenticated]

    def get_queryset(self):
        user = self.request.user
        if user.is_staff:
            return BorrowRecord.objects.select_related("book", "borrower").all()
        return BorrowRecord.objects.select_related("book", "borrower").filter(
            borrower=user
        )

    def get_serializer_class(self):
        if self.action == "retrieve":
            return BorrowRecordDetailSerializer
        return BorrowRecordSerializer

    def perform_create(self, serializer):
        """Tự động gán người mượn là user hiện tại"""
        serializer.save(borrower=self.request.user)

    @action(detail=True, methods=["post"])
    def return_book(self, request, pk=None):
        """Trả sách"""
        borrow_record = self.get_object()

        if borrow_record.status == "returned":
            return Response(
                {"error": "Sách đã được trả rồi."}, status=status.HTTP_400_BAD_REQUEST
            )

        from django.utils import timezone

        borrow_record.return_date = timezone.now().date()
        borrow_record.status = "returned"
        borrow_record.save()

        serializer = self.get_serializer(borrow_record)
        return Response(serializer.data)

    @action(detail=False, methods=["get"])
    def my_borrows(self, request):
        """Lấy danh sách sách đang mượn của user hiện tại"""
        borrows = self.get_queryset().filter(status="borrowed")
        page = self.paginate_queryset(borrows)
        if page is not None:
            serializer = self.get_serializer(page, many=True)
            return self.get_paginated_response(serializer.data)
        serializer = self.get_serializer(borrows, many=True)
        return Response(serializer.data)

    @action(detail=False, methods=["get"])
    def overdue(self, request):
        """Lấy danh sách sách quá hạn"""
        from django.utils import timezone

        overdue_records = self.get_queryset().filter(
            status="borrowed", due_date__lt=timezone.now().date()
        )
        page = self.paginate_queryset(overdue_records)
        if page is not None:
            serializer = self.get_serializer(page, many=True)
            return self.get_paginated_response(serializer.data)
        serializer = self.get_serializer(overdue_records, many=True)
        return Response(serializer.data)


class UserViewSet(viewsets.ReadOnlyModelViewSet):
    """ViewSet cho xem thông tin user"""

    queryset = User.objects.all()
    serializer_class = UserSerializer
    permission_classes = [IsAuthenticated]

    @action(detail=False, methods=["get"])
    def me(self, request):
        """Lấy thông tin user hiện tại"""
        serializer = self.get_serializer(request.user)
        return Response(serializer.data)
